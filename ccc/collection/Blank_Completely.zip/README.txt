HOW TO USE:

1. Import the JSON file
2. Go to bang1338.xyz/ccc/collection/titleless.js, copy that script
3. Go back to Comic Studio, F12 -> Consoles or Ctrl + Shift + I -> Consoles
4. Paste the script then enter
5. Re-input the title


CREDITS:
- treezey, for idea and method (but differents)
- Ooh, titleless method (long subdomain method)

JSON FINISH DATE: 19.08.23 07:30:11
JSON CRC32: D4E6678A
JSON SHA3-512: 91B95E3505D16C01EA5423D15CCAD19B20B9ACAF4810CECFFD2E74633E95DB3A0E313A6375D337518361AA429AE2BA6F3C1CB5B549D5EEB0DC248D82A5F5776A

- bang1338, Cursed Comic OG